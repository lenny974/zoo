<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ZOO</title>
    <link rel="stylesheet" href="style2.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet" type="text/css" href="css/slick.css"/>
    <link rel="stylesheet" type="text/css" href="css/slick-theme.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-CG+TNH9/Wv/7wwIrcJj88e7TQ2HyIePlV8w0pEJjSh7hiz78Bdq/nRU7W/JjKUDFV7TcRbFvz8w2jpjqoiMzjw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Roboto+Flex:opsz,wght@8..144,100;8..144,300;8..144,500;8..144,700;8..144,900&display=swap"
      rel="stylesheet"
    />
    <script src="js/jquery.min.js"></script>
  <script src="js/slick.min.js"></script>
  <script src="script.js"></script>
  </head>
  <body>
   
    <nav>

      <a href="#" class="nav-icon" aria-label="visit homepage" aria-current="page">
        <img src="logo.webp" style="transform:rotate(0deg)" alt="SIDOME"  ;>
        
      </a>

      <div class="main-navlinks">
        <button class="hamburger" type="button" aria-label="Toggle navigation" aria-expanded="false">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="navlinks-container">
          <a href="#" aria-current="page">Nos Animeaux</a>
          <a href="nos_services.html">Plan du ZOO</a>
          <a href="#">EMPLOYE</a>
         
    
          <h2 class="SIDOME">ZOO</h2>
        </div>
      </div>
    </nav>
</body>
</html>




<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo";

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Traiter la soumission du formulaire de modification
if (isset($_POST["submit"])) {
    $id = intval($_POST["id"]);
    $race_id = intval($_POST["race_id"]);
    $date_naissance = mysqli_real_escape_string($conn, $_POST["date_naissance"]);
    $sexe = mysqli_real_escape_string($conn, $_POST["sexe"]);
    $pseudo = mysqli_real_escape_string($conn, $_POST["pseudo"]);
    $commentaire = mysqli_real_escape_string($conn, $_POST["commentaire"]);

    $sql = "UPDATE animal SET race_id=$race_id, date_naissance='$date_naissance', Sexe='$sexe', Pseudo='$pseudo', Commentaire='$commentaire' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Les informations ont été mises à jour avec succès.</p>";
    } else {
        echo "Erreur lors de la mise à jour des informations : " . $conn->error;
    }
}

// Exécuter la requête SQL pour récupérer les informations de la table animal
$sql = "SELECT * FROM animal";
$result = $conn->query($sql);

// Ajouter le style CSS
echo "<link rel='stylesheet' type='text/css' href='style.css'>";

// Ajouter un titre
echo "<h1>Modification des animaux</h1>";

// Afficher les informations de la table animal
if ($result->num_rows > 0) {
    // En-têtes du tableau
    echo "<div class='container'>";
    echo "<table>
            <tr>
                <th>ID</th>
                <th>Race ID</th>
                <th>Date de naissance</th>
                <th>Sexe</th>
                <th>Pseudo</th>
                <th>Commentaire</th>
                <th>Actions</th>
            </tr>";

    // Affichage des données de chaque ligne avec formulaire de modification
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <form method='post'>
                    <td><input type='text' name='id' value='".$row["id"]."'></td>
                    <td><input type='text' name='race_id' value='".$row["race_id"]."'></td>
                    <td><input type='date' name='date_naissance' value='".$row["date_naissance"]."'></td>
                    <td>
                        <select name='sexe'>
                            <option value='M' ".($row['Sexe'] == 'M' ? 'selected' : '').">M</option>
                            <option value='F' ".($row['Sexe'] == 'F' ? 'selected' : '').">F</option>
                        </select>
                    </td>
                    <td><input type='text' name='pseudo' value='".$row["Pseudo"]."'></td>
                    <td><input type='text' name='commentaire' value='".$row["Commentaire"]."'></td>
                    <td>
                        <input type='hidden' name='id' value='".$row["id"]."'>
                        <input type='submit' name='submit' value='Enregistrer'>
                        </td>
                    </form>
                  </tr>";
        }
    
                echo "</table>";
                echo "</div>";
            } else {
                echo "0 results";
            }
           
    
            
            // Fermer la connexion
            $conn->close();
            ?>
