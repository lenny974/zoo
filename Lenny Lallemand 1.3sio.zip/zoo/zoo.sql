-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: 127.0.0.1
-- Généré le : Jeu 11 Mai 2023 à 01:30
-- Version du serveur: 5.5.10
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `zoo`
--

-- --------------------------------------------------------

--
-- Structure de la table `animal`
--

CREATE TABLE IF NOT EXISTS `animal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `race_id` int(255) NOT NULL,
  `date_naissance` date NOT NULL,
  `Sexe` varchar(255) NOT NULL,
  `Pseudo` varchar(255) NOT NULL,
  `Commentaire` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `race_id` (`race_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `animal`
--

INSERT INTO `animal` (`id`, `race_id`, `date_naissance`, `Sexe`, `Pseudo`, `Commentaire`) VALUES

(3, 12, '2000-05-28', 'M', 'Loup', 'dezdf');

-- --------------------------------------------------------

--
-- Structure de la table `enclos`
--

CREATE TABLE IF NOT EXISTS `enclos` (
  `id` varchar(4) NOT NULL,
  `nom_enclos` varchar(255) DEFAULT NULL,
  `capacite_max_animaux` int(11) NOT NULL,
  `taille` varchar(100) DEFAULT NULL,
  `eau` varchar(4) NOT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `responsable_id` (`responsable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `enclos`
--

INSERT INTO `enclos` (`id`, `nom_enclos`, `capacite_max_animaux`, `taille`, `eau`, `responsable_id`) VALUES

('25', 'Kobz', 98, '75o', 'non', 64);

-- --------------------------------------------------------

--
-- Structure de la table `especes`
--

CREATE TABLE IF NOT EXISTS `especes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_race` varchar(255) NOT NULL,
  `type_nourriture` varchar(100) NOT NULL,
  `duree_vie_moyenne` varchar(100) NOT NULL,
  `aquatique` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `especes`
--

INSERT INTO `especes` (`id`, `nom_race`, `type_nourriture`, `duree_vie_moyenne`, `aquatique`) VALUES

(14, 'Lens', 'Carnivore', '12', 'oui');

-- --------------------------------------------------------

--
-- Structure de la table `loc_animaux`
--

CREATE TABLE IF NOT EXISTS `loc_animaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `animal_id` int(11) NOT NULL,
  `enclos_id` varchar(4) DEFAULT NULL,
  `date_arrivee` date DEFAULT NULL,
  `date_sortie` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enclos_id` (`enclos_id`),
  KEY `animal_id` (`animal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `loc_animaux`
--


-- --------------------------------------------------------

--
-- Structure de la table `personnels`
--

CREATE TABLE IF NOT EXISTS `personnels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL,
  `sexe` varchar(100) NOT NULL,
  `login` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `fonction` varchar(100) NOT NULL,
  `salaire` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=223 ;

--
-- Contenu de la table `personnels`
--

INSERT INTO `personnels` (`id`, `nom`, `prenom`, `date_naissance`, `sexe`, `login`, `mdp`, `fonction`, `salaire`) VALUES
(212, 'Tony', 'Montana', '2023-04-03', 'Homme', 'admin', 'admin', 'Directeur', '120'),
(222, 'Niskine', 'Kaloush', '2020-04-10', 'Femme', 'user', 'user', 'Personnel', '99999');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `animal`
--
ALTER TABLE `animal`
  ADD CONSTRAINT `animal_ibfk_1` FOREIGN KEY (`race_id`) REFERENCES `especes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `enclos`
--
ALTER TABLE `enclos`
  ADD CONSTRAINT `enclos_ibfk_1` FOREIGN KEY (`responsable_id`) REFERENCES `personnels` (`id`);

--
-- Contraintes pour la table `loc_animaux`
--
ALTER TABLE `loc_animaux`
  ADD CONSTRAINT `loc_animaux_ibfk_3` FOREIGN KEY (`animal_id`) REFERENCES `animal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `loc_animaux_ibfk_2` FOREIGN KEY (`enclos_id`) REFERENCES `enclos` (`id`);
