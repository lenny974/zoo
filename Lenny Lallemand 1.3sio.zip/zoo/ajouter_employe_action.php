<?php

// Récupérer les données du formulaire
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$date_naissance = $_POST['date_naissance'];
$sexe = $_POST['sexe'];
$login = $_POST['login'];
$mdp = $_POST['mdp'];
$fonction = $_POST['fonction'];
$salaire = $_POST['salaire'];

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}

// Set charset to utf8
if (!$conn->set_charset("utf8")) {
    printf("Erreur lors du chargement du jeu de caractères utf8 : %s\n", $conn->error);
}

// Requête d'insertion
$sql = "INSERT INTO personnels (nom, prenom, date_naissance, sexe, login, mdp, fonction, salaire) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
// Continue from the previous code
if ($stmt) {
    // Bind parameters and execute statement
    $stmt->bind_param("sssssssi", $nom, $prenom, $date_naissance, $sexe, $login, $mdp, $fonction, $salaire);

    if ($stmt->execute()) {
        $message = "L'employé a été ajouté avec succès.";
    } else {
        $message = "Erreur: " . $sql . "<br>" . $conn->error;
    }
} else {
    $message = "Erreur de préparation de la requête: " . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();

// HTML part
?>

