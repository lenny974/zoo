<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification si la connexion a réussi
if (!$conn) {
    echo "Erreur de connexion à la base de données: " . mysqli_connect_error();
    exit();
}

$a = $_POST["login"];
$b = $_POST["mdp"];
$c = $_POST["fonction"];

$requete = "SELECT * FROM personnels WHERE login='$a' AND mdp='$b' AND fonction='$c'" ;
$resultat = mysqli_query($conn, $requete);
$ligne = mysqli_num_rows($resultat);

if (($ligne == 1) && ($c == "directeur")) {
    $_SESSION["utilisateur"] = mysqli_fetch_assoc($resultat);
    header("Location: index1.html");
    exit();
} elseif (($ligne == 1) && ($c == "personnel")) {
    $_SESSION["utilisateur"] = mysqli_fetch_assoc($resultat);
    header("Location: index2.html");
    exit();
} else {
    header("Location: index.html");
    exit();
}

// Fermeture de la connexion à la base de données
mysqli_close($conn);
?>