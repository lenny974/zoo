<?php

// Récupérer les données du formulaire
$race_id = $_POST['race_id'];
$date_naissance = $_POST['date_naissance'];
$sexe = $_POST['sexe'];
$pseudo = $_POST['pseudo'];
$commentaire = $_POST['commentaire'];

// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}

// Définir le jeu de caractères à utf8
if (!$conn->set_charset("utf8")) {
    printf("Erreur lors du chargement du jeu de caractères utf8 : %s\n", $conn->error);
}

// Requête d'insertion
$sql = "INSERT INTO animal (race_id, date_naissance, sexe, pseudo, commentaire) VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if ($stmt) {
    // Lier les paramètres et exécuter la requête
    $stmt->bind_param("issss", $race_id, $date_naissance, $sexe, $pseudo, $commentaire);

    if ($stmt->execute()) {
        $message = "L'animal a été ajouté avec succès.";
    } else {
        $message = "Erreur lors de l'exécution de la requête: " . $stmt->error;
    }
    $stmt->close();
} else {
    $message = "Erreur de préparation de la requête: " . $conn->error;
}

// Fermer la connexion
$conn->close();


?>
