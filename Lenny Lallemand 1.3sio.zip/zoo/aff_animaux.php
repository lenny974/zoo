<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ZOO</title>
    <link rel="stylesheet" href="style2.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet" type="text/css" href="css/slick.css"/>
    <link rel="stylesheet" type="text/css" href="css/slick-theme.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-CG+TNH9/Wv/7wwIrcJj88e7TQ2HyIePlV8w0pEJjSh7hiz78Bdq/nRU7W/JjKUDFV7TcRbFvz8w2jpjqoiMzjw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&family=Roboto+Flex:opsz,wght@8..144,100;8..144,300;8..144,500;8..144,700;8..144,900&display=swap"
      rel="stylesheet"
    />
    <script src="js/jquery.min.js"></script>
  <script src="js/slick.min.js"></script>
  <script src="script.js"></script>
  </head>
  <body>
   
    <nav>

      <a href="#" class="nav-icon" aria-label="visit homepage" aria-current="page">
        <img src="logo.webp" style="transform:rotate(0deg)" alt="SIDOME"  ;>
        
      </a>

      <div class="main-navlinks">
        <button class="hamburger" type="button" aria-label="Toggle navigation" aria-expanded="false">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="navlinks-container">
          <a href="#" aria-current="page">Nos Animeaux</a>
          <a href="nos_services.html">Plan du ZOO</a>
          <a href="#">EMPLOYE</a>
         
    
          <h2 class="SIDOME">ZOO</h2>
        </div>
      </div>
    </nav>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo";

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Exécuter la requête SQL pour récupérer les informations de la table animal
$sql = "SELECT * FROM animal";
$result = $conn->query($sql);

// Ajouter le style CSS
echo "<style>
    body {
        background-image: url(zoofond.jpg);
        background-size: 100%;
        text-align: center;
    }

    .container {
        display: inline-block;
        margin-bottom: 20px;
    }

    table {
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        width: 100%;
        background-color: rgba(255, 255, 255, 0.7);
        margin: 0 auto;
    }
    th, td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    button {
        background-color: #f44336;
        color: white;
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
        border: none;
        border-radius: 4px;
        margin-top: 5cm;
    }
    button:hover {
        background-color: #da190b;
    }
</style>";

// Ajouter un titre
echo "<h1>Liste des animaux</h1>";

// Afficher les informations de la table animal
if ($result->num_rows > 0) {
    // En-têtes du tableau
    echo "<div class='container'>";
    echo "<table>
            <tr>
                <th>ID</th>
                <th>Race ID</th>
                <th>Date de naissance</th>
                <th>Sexe</th>
                <th>Pseudo</th>
                <th>Commentaire</th>
            </tr>";
    
    // Affichage des données de chaque ligne
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row["id"]."</td>
                <td>".$row["race_id"]."</td>
                <td>".$row["date_naissance"]."</td>
                <td>".$row["Sexe"]."</td>
                <td>".$row["Pseudo"]."</td>
                <td>".$row["Commentaire"]."</td>
              </tr>";
    }
    echo "</table>";
    echo "</div>";
} else {
    echo "0 results";
}

// Ajouter un bouton de retour
echo "<button onclick='window.history.back()'>Retour</button>";

//
// Fermer la connexion
$conn->close();
?>
