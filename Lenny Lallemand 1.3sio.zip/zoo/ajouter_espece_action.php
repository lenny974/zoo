<?php
	// Connexion à la base de données
	$serveur = "localhost";
	$utilisateur = "root";
	$motdepasse = "";
	$basededonnees = "zoo";

	$connexion = mysqli_connect($serveur, $utilisateur, $motdepasse, $basededonnees);

	// Vérifier si la connexion est établie
	if (!$connexion) {
		die("La connexion a échoué: " . mysqli_connect_error());
	}

	// Récupérer les valeurs du formulaire
	$nom_race = $_POST['nom_race'];
	$type_nourriture = $_POST['type_nourriture'];
	$duree_vie_moyenne = $_POST['duree_vie_moyenne'];
	$aquatique = $_POST['aquatique'];

	// Préparer la requête SQL
	$sql = "INSERT INTO especes (nom_race, type_nourriture, duree_vie_moyenne, aquatique) VALUES ('$nom_race', '$type_nourriture', '$duree_vie_moyenne', '$aquatique')";

	// Exécuter la requête SQL
	if (mysqli_query($connexion, $sql)) {
		// Afficher un message de succès
		echo "<p>L'espèce a été ajoutée avec succès.</p>";
	} else {
		echo "Erreur: " . $sql . "<br>" . mysqli_error($connexion);
	}

	// Fermer la connexion à la base de données
	mysqli_close($connexion);
?>

	